// Función que recibe un parámetro (hora) y devuelve un saludo
function obtenerSaludo(hora) {
    if (hora < 12) {
        return "¡Buenos días!";
    } else if (hora < 18) {
        return "¡Buenas tardes!";
    } else {
        return "¡Buenas noches!";
    }
}

// Manipulación del DOM: cambiar el contenido del título dinámicamente
let titulo = document.getElementById("titulo");
let fecha = new Date();
let hora = fecha.getHours();
titulo.textContent = obtenerSaludo(hora) + " Bienvenido a mi Portafolio";
